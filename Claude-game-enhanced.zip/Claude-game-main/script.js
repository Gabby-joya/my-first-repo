/* ==============================
   BLADE DUEL — script.js (Enhanced)
   ============================== */

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

// ── Constants ────────────────────────
const GRAVITY   = 0.5;
const JUMP_FORCE = -11;
const GROUND    = 300;
const SPEED     = 3.5;

const WEAPONS = [
  { id: 'balanced', label: 'Balanced Sword',  attackTimer: 18, attackCooldown: 35, dmgMult: 1.0 },
  { id: 'fast',     label: 'Fast Blade ×2spd', attackTimer: 9,  attackCooldown: 17, dmgMult: 0.5 },
  { id: 'heavy',    label: 'Heavy Maul ×2dmg', attackTimer: 36, attackCooldown: 70, dmgMult: 2.0 },
];

const AI_LEVELS = {
  easy:   { reactionDist: 140, attackDist: 70,  jumpChance: 0.004, blockChance: 0.01,  parryChance: 0.002 },
  medium: { reactionDist: 100, attackDist: 90,  jumpChance: 0.008, blockChance: 0.04,  parryChance: 0.01  },
  hard:   { reactionDist:  70, attackDist: 90,  jumpChance: 0.012, blockChance: 0.10,  parryChance: 0.025 },
  boss:   { reactionDist:  45, attackDist: 92,  jumpChance: 0.018, blockChance: 0.22,  parryChance: 0.06  },
};

const BLOCK_COOLDOWN_FRAMES  = 120;
const PARRY_COOLDOWN_FRAMES  = 300;
const BLOCK_STUN_FRAMES      = 60;
const PARRY_MISS_STUN_FRAMES = 30;
const PARRY_HIT_STUN_FRAMES  = 90;
const CHIP_DURATION_FRAMES   = 300;
const SWORD_BREAK_FRAMES     = 240;

const PLATFORMS = [
  { x: 100, y: 240, w: 120, h: 12 },
  { x: 270, y: 200, w: 100, h: 12 },
  { x: 430, y: 240, w: 120, h: 12 },
  { x: 180, y: 160, w: 80,  h: 12 },
  { x: 370, y: 155, w: 80,  h: 12 },
];

let mode         = 'vs';
let aiDifficulty = 'medium';
let p1WeaponIdx  = 0;
let gameLoop     = null;
let gameOver     = false;
let p1, p2;
let keys         = {};
let msgTimer     = 0;

function makeFighter(x, color, flip, weaponIdx) {
  const wp = WEAPONS[weaponIdx !== undefined ? weaponIdx : 0];
  return {
    x, y: GROUND, w: 28, h: 48,
    vx: 0, vy: 0,
    hp: 100, maxHp: 100,
    onGround: false,
    attacking: false,
    attackTimer: 0,
    attackCooldown: 0,
    lastHitTime: 0,
    healTimer: 0,
    color, flip,
    dead: false,
    weapon: wp,
    blocking: false,
    parrying: false,
    parryActive: false,
    blockTimer: 0,
    parryTimer: 0,
    blockCooldown: 0,
    parryCooldown: 0,
    blockHitsInRow: 0,
    stunTimer: 0,
    swordChipped: false,
    chipTimer: 0,
    swordBroken: false,
    breakTimer: 0,
  };
}

function buildWeaponUI() {
  const wrap = document.getElementById('weapon-select');
  if (!wrap) return;
  wrap.innerHTML = '<span style="color:#aaa;font-size:12px">Weapon: </span>';
  WEAPONS.forEach((wp, i) => {
    const btn = document.createElement('button');
    btn.className = 'wp-btn' + (i === p1WeaponIdx ? ' active' : '');
    btn.textContent = wp.label;
    btn.onclick = () => {
      p1WeaponIdx = i;
      document.querySelectorAll('.wp-btn').forEach((b, j) => b.classList.toggle('active', j === i));
    };
    wrap.appendChild(btn);
  });
}

function buildDifficultyUI() {
  const wrap = document.getElementById('difficulty-select');
  if (!wrap) return;
  wrap.innerHTML = '<span style="color:#aaa;font-size:12px">AI Difficulty: </span>';
  ['easy','medium','hard','boss'].forEach(d => {
    const btn = document.createElement('button');
    btn.className = 'diff-btn' + (d === aiDifficulty ? ' active' : '');
    btn.textContent = d.charAt(0).toUpperCase() + d.slice(1);
    btn.onclick = () => {
      aiDifficulty = d;
      document.querySelectorAll('.diff-btn').forEach(b => b.classList.toggle('active', b.textContent.toLowerCase() === d));
    };
    wrap.appendChild(btn);
  });
}

function startGame(m) {
  mode = m;
  document.getElementById('menu').style.display    = 'none';
  document.getElementById('gameArea').style.display = 'flex';

  const isVS = mode === 'vs';
  document.getElementById('p1name').textContent = isVS ? 'YOU' : 'PLAYER 1';
  document.getElementById('p2name').textContent = isVS ? 'CPU' : 'PLAYER 2';
  document.getElementById('p2hp').style.background = isVS ? '#c84b4b' : '#4b8cc8';

  p1 = makeFighter(120, '#c8a84b', false, isVS ? p1WeaponIdx : 0);
  p2 = makeFighter(480, '#4b8cc8', true,  0);

  let hint;
  if (isVS) {
    hint = 'A/D move · W jump · Space attack · F block · R parry  |  Difficulty: ' + aiDifficulty.toUpperCase();
  } else {
    hint = 'P1: A/D · W jump · S atk · E block · R parry    |    P2: ←/→ · ↑ jump · ↓ atk · K block · L parry';
  }
  document.getElementById('controls-hint').textContent = hint;

  gameOver = false;
  keys     = {};
  msgTimer = 0;
  document.getElementById('msg').textContent = '';

  if (gameLoop) cancelAnimationFrame(gameLoop);
  loop();
}

function backToMenu() {
  if (gameLoop) cancelAnimationFrame(gameLoop);
  gameLoop = null;
  document.getElementById('menu').style.display    = 'flex';
  document.getElementById('gameArea').style.display = 'none';
  document.getElementById('msg').textContent = '';
}

document.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
});
document.addEventListener('keyup', e => { keys[e.code] = false; });

function onPlatform(f, plat) {
  return (
    f.x + f.w > plat.x && f.x < plat.x + plat.w &&
    f.y + f.h > plat.y && f.y + f.h < plat.y + plat.h + 8 && f.vy >= 0
  );
}

function resolvePhysics(f) {
  f.onGround = false;
  if (f.y + f.h >= GROUND) { f.y = GROUND - f.h; f.vy = 0; f.onGround = true; }
  for (const p of PLATFORMS) {
    if (onPlatform(f, p)) { f.y = p.y - f.h; f.vy = 0; f.onGround = true; break; }
  }
  f.x = Math.max(0, Math.min(canvas.width - f.w, f.x));
}

function resolveCollision() {
  if (p1.dead || p2.dead) return;
  const overlap = (p1.x + p1.w) - p2.x;
  if (overlap > 0 && p1.x < p2.x) {
    const half = overlap / 2;
    p1.x -= half;
    p2.x += half;
  }
}

function update(f, moveL, moveR, doJump, doAtk, doBlock, doParry) {
  if (f.dead) return;

  if (f.blockCooldown  > 0) f.blockCooldown--;
  if (f.parryCooldown  > 0) f.parryCooldown--;
  if (f.chipTimer      > 0) { f.chipTimer--;  if (f.chipTimer  === 0) f.swordChipped = false; }
  if (f.breakTimer     > 0) { f.breakTimer--; if (f.breakTimer === 0) f.swordBroken  = false; }

  if (f.stunTimer > 0) {
    f.stunTimer--;
    f.vy += GRAVITY;
    f.x  += f.vx * 0.3;
    f.y  += f.vy;
    resolvePhysics(f);
    if (f.attackTimer > 0) f.attackTimer--;
    f.attacking = false; f.blocking = false; f.parrying = false; f.parryActive = false;
    return;
  }

  // Parry logic
  if (doParry && f.parryCooldown === 0 && !doAtk) {
    if (!f.parrying) {
      f.parrying      = true;
      f.parryActive   = true;
      f.parryTimer    = 12;
      f.parryCooldown = PARRY_COOLDOWN_FRAMES;
      f.blocking      = false;
    }
  }
  if (f.parryActive) {
    if (f.parryTimer > 0) {
      f.parryTimer--;
    } else {
      // window closed without catching — miss stun
      f.parrying    = false;
      f.parryActive = false;
      f.stunTimer   = PARRY_MISS_STUN_FRAMES;
      showMsg('❌ Whiffed parry! Stunned 0.5s!');
    }
  }

  // Block logic
  if (doBlock && !f.parrying && f.blockCooldown === 0 && !doAtk) {
    f.blocking = true;
  } else if (!doBlock) {
    if (f.blocking) { f.blocking = false; f.blockHitsInRow = 0; }
  }
  // If block pressed but on cooldown, just don't block
  if (doBlock && f.blockCooldown > 0) f.blocking = false;

  // Movement
  if (!f.parrying) {
    if      (moveL) { f.vx = -SPEED; f.flip = true;  }
    else if (moveR) { f.vx =  SPEED; f.flip = false; }
    else            { f.vx *= 0.7; }
  } else {
    f.vx *= 0.5;
  }

  if (doJump && f.onGround && !f.parrying) { f.vy = JUMP_FORCE; f.onGround = false; }

  if (f.attackCooldown > 0) f.attackCooldown--;
  if (f.attackTimer    > 0) { f.attackTimer--; f.attacking = true; }
  else                      { f.attacking = false; }

  if (doAtk && f.attackCooldown === 0 && !f.swordBroken) {
    const wp         = f.weapon;
    f.attacking      = true;
    f.attackTimer    = wp.attackTimer;
    f.attackCooldown = wp.attackCooldown;
    f.blocking       = false;
    if (f.parrying)  { f.parrying = false; f.parryActive = false; f.parryTimer = 0; }
  }

  f.vy += GRAVITY;
  f.x  += f.vx;
  f.y  += f.vy;
  resolvePhysics(f);

  const now = Date.now();
  if (now - f.lastHitTime > 3000 && f.hp < f.maxHp) {
    f.healTimer += 1 / 60;
    if (f.healTimer >= 1) { f.healTimer = 0; f.hp = Math.min(f.maxHp, f.hp + 4); }
  } else if (now - f.lastHitTime <= 3000) {
    f.healTimer = 0;
  }
}

function checkHit(attacker, target) {
  if (!attacker.attacking || target.dead || attacker.dead) return;

  const ax = attacker.flip ? attacker.x - 36 : attacker.x + attacker.w;
  const aw = 36, ah = 24;
  const ay = attacker.y + 10;

  if (!(ax < target.x + target.w && ax + aw > target.x && ay < target.y + target.h && ay + ah > target.y)) return;

  // PARRY
  if (target.parrying && target.parryActive && target.parryTimer > 0) {
    target.parrying    = false;
    target.parryActive = false;
    target.parryTimer  = 0;
    attacker.attacking    = false;
    attacker.attackTimer  = 0;

    if (Math.random() < 0.01) {
      attacker.swordBroken  = true;
      attacker.breakTimer   = SWORD_BREAK_FRAMES;
      attacker.swordChipped = false;
      attacker.chipTimer    = 0;
      showMsg('💔 SWORD SHATTERED! Disarmed 4s!');
    } else {
      showMsg('🌀 PERFECT PARRY! Attacker stunned 1.5s!');
    }
    attacker.stunTimer = PARRY_HIT_STUN_FRAMES;
    return;
  }

  // BLOCK
  if (target.blocking) {
    attacker.attacking   = false;
    attacker.attackTimer = 0;

    if (!attacker.swordBroken && !attacker.swordChipped && Math.random() < 0.05) {
      attacker.swordChipped = true;
      attacker.chipTimer    = CHIP_DURATION_FRAMES;
      showMsg('🔩 Sword chipped on shield! Half damage 5s!');
    }

    // Apply block cooldown when hit
    target.blockCooldown = BLOCK_COOLDOWN_FRAMES;
    target.blocking      = false;

    target.blockHitsInRow++;
    if (target.blockHitsInRow >= 3) {
      target.blockHitsInRow = 0;
      target.stunTimer      = BLOCK_STUN_FRAMES;
      showMsg('💢 GUARD BROKEN! Stunned 1s!');
    } else {
      showMsg('🛡 BLOCKED! (' + target.blockHitsInRow + '/3)');
    }
    return;
  }

  // NORMAL HIT
  target.blockHitsInRow = 0;
  const crit = Math.random() < 0.02;
  let baseDmg = crit ? 50 : Math.floor(Math.random() * 11) + 10;
  baseDmg = Math.round(baseDmg * attacker.weapon.dmgMult);
  if (attacker.swordChipped) baseDmg = Math.round(baseDmg * 0.5);

  target.hp          = Math.max(0, target.hp - baseDmg);
  target.lastHitTime = Date.now();
  attacker.attacking    = false;
  attacker.attackTimer  = 0;

  showMsg(crit ? '💥 CRITICAL HIT! -' + baseDmg : '-' + baseDmg + ' damage');
  if (target.hp <= 0) target.dead = true;
}

function aiUpdate(ai, player) {
  const lvl = AI_LEVELS[aiDifficulty];
  const dx  = player.x - ai.x;
  const adx = Math.abs(dx);

  const doParry = player.attacking && adx < lvl.attackDist + 20
    && ai.parryCooldown === 0 && Math.random() < lvl.parryChance;

  const doBlock = player.attacking && adx < lvl.attackDist + 15
    && ai.blockCooldown === 0 && !doParry && Math.random() < lvl.blockChance;

  return {
    moveL:  dx < -lvl.reactionDist * 0.3 && !doBlock && !doParry,
    moveR:  dx >  lvl.reactionDist * 0.3 && !doBlock && !doParry,
    doJump: ai.onGround && ((adx < 60 && player.y < ai.y - 30) || Math.random() < lvl.jumpChance),
    doAtk:  adx < lvl.attackDist && ai.attackCooldown === 0 && !doBlock && !doParry && !ai.swordBroken,
    doBlock, doParry,
  };
}

function showMsg(text) {
  document.getElementById('msg').textContent = text;
  msgTimer = 140;
}

function getStatusIcons(f) {
  let s = '';
  if (f.stunTimer   > 0) s += '💫 ';
  if (f.blocking)        s += '🛡 ';
  if (f.parrying)        s += '🌀 ';
  if (f.swordBroken)     s += '💔 ';
  if (f.swordChipped)    s += '🔩 ';
  return s.trim();
}

function updateHUD() {
  const p1pct = Math.max(0, (p1.hp / p1.maxHp) * 100);
  const p2pct = Math.max(0, (p2.hp / p2.maxHp) * 100);
  document.getElementById('p1hp').style.width     = p1pct + '%';
  document.getElementById('p2hp').style.width     = p2pct + '%';
  document.getElementById('p1hptext').textContent = p1.hp + ' / 100';
  document.getElementById('p2hptext').textContent = p2.hp + ' / 100';
  document.getElementById('p1status').textContent = getStatusIcons(p1);
  document.getElementById('p2status').textContent = getStatusIcons(p2);

  // Cooldown bars
  updateCooldownBar('p1-block-cd', p1.blockCooldown,  BLOCK_COOLDOWN_FRAMES);
  updateCooldownBar('p1-parry-cd', p1.parryCooldown,  PARRY_COOLDOWN_FRAMES);
  updateCooldownBar('p2-block-cd', p2.blockCooldown,  BLOCK_COOLDOWN_FRAMES);
  updateCooldownBar('p2-parry-cd', p2.parryCooldown,  PARRY_COOLDOWN_FRAMES);
}

function updateCooldownBar(id, current, max) {
  const el = document.getElementById(id);
  if (!el) return;
  const pct = current > 0 ? (current / max) * 100 : 0;
  el.style.width = pct + '%';
}

function drawFighter(f) {
  if (f.dead) return;
  const stunFlash = f.stunTimer > 0 && Math.floor(f.stunTimer / 4) % 2 === 0;
  const col = stunFlash ? '#666' : f.color;

  ctx.save();
  ctx.translate(f.x + f.w / 2, f.y + f.h / 2);
  if (f.flip) ctx.scale(-1, 1);

  ctx.fillStyle = col;
  ctx.fillRect(-f.w / 2, -f.h / 2, f.w, f.h);

  ctx.fillStyle = '#e8c89a';
  ctx.beginPath();
  ctx.arc(0, -f.h / 2 - 8, 10, 0, Math.PI * 2);
  ctx.fill();

  if (f.blocking) {
    ctx.fillStyle   = 'rgba(100,180,255,0.4)';
    ctx.strokeStyle = '#88ddff';
    ctx.lineWidth   = 2;
    ctx.beginPath();
    ctx.ellipse(-f.w / 2 - 8, 0, 10, 22, 0, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
  }

  if (f.parrying && f.parryActive) {
    ctx.strokeStyle = 'rgba(255,220,50,0.9)';
    ctx.lineWidth   = 3;
    ctx.beginPath();
    ctx.arc(0, 0, f.w + 4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,180,0,0.4)';
    ctx.lineWidth   = 8;
    ctx.beginPath();
    ctx.arc(0, 0, f.w + 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (f.swordBroken) {
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(f.w/2 - 2, 0); ctx.lineTo(f.w/2 + 7, -7);
    ctx.stroke();
    ctx.fillStyle = '#555';
    ctx.fillText('✕', f.w/2 + 8, -8);
  } else if (f.attacking) {
    const swCol = f.swordChipped ? '#cc8800' : '#ffe04b';
    ctx.strokeStyle = swCol; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(f.w/2, -4); ctx.lineTo(f.w/2 + 36, 8); ctx.stroke();
    ctx.fillStyle = swCol;
    ctx.beginPath(); ctx.arc(f.w/2 + 36, 8, 5, 0, Math.PI * 2); ctx.fill();
  } else {
    ctx.strokeStyle = f.swordChipped ? '#b8860b' : '#aaa';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(f.w/2 - 2, 0); ctx.lineTo(f.w/2 + 18, -20); ctx.stroke();
  }

  ctx.restore();
}

function drawScene() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#0d0d1a'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'rgba(255,255,255,0.15)';
  for (let i = 0; i < 8; i++) ctx.fillRect(60 + i*80, 20 + Math.sin(i)*15, 1, 1);
  ctx.fillStyle = '#1a1a2e'; ctx.fillRect(0, GROUND, canvas.width, canvas.height - GROUND);
  ctx.fillStyle = '#252540'; ctx.fillRect(0, GROUND, canvas.width, 4);
  for (const p of PLATFORMS) {
    ctx.fillStyle = '#252540'; ctx.fillRect(p.x, p.y, p.w, p.h);
    ctx.fillStyle = '#3a3a60'; ctx.fillRect(p.x, p.y, p.w, 3);
  }
  drawFighter(p1);
  drawFighter(p2);
}

function loop() {
  if (gameOver) { gameLoop = requestAnimationFrame(loop); drawScene(); return; }

  const p1moveL = keys['KeyA'];
  const p1moveR = keys['KeyD'];
  const p1jump  = keys['KeyW'];
  let p1atk, p1block, p1parry;

  if (mode === 'vs') {
    p1atk   = keys['Space'];
    p1block = keys['KeyF'];
    p1parry = keys['KeyR'];
  } else {
    p1atk   = keys['KeyS'];
    p1block = keys['KeyE'];
    p1parry = keys['KeyR'];
  }

  let p2moveL, p2moveR, p2jump, p2atk, p2block, p2parry;
  if (mode === 'vs') {
    const ai = aiUpdate(p2, p1);
    p2moveL = ai.moveL; p2moveR = ai.moveR;
    p2jump  = ai.doJump; p2atk = ai.doAtk;
    p2block = ai.doBlock; p2parry = ai.doParry;
  } else {
    p2moveL = keys['ArrowLeft']; p2moveR = keys['ArrowRight'];
    p2jump  = keys['ArrowUp'];  p2atk   = keys['ArrowDown'];
    p2block = keys['KeyK'];     p2parry = keys['KeyL'];
  }

  update(p1, p1moveL, p1moveR, p1jump, p1atk, p1block, p1parry);
  update(p2, p2moveL, p2moveR, p2jump, p2atk, p2block, p2parry);
  resolveCollision();
  checkHit(p1, p2);
  checkHit(p2, p1);

  if (msgTimer > 0) { msgTimer--; if (msgTimer === 0) document.getElementById('msg').textContent = ''; }

  if ((p1.dead || p2.dead) && !gameOver) {
    gameOver = true;
    const winner = p1.dead
      ? (mode === 'vs' ? 'CPU WINS' : 'PLAYER 2 WINS')
      : (mode === 'vs' ? 'YOU WIN!' : 'PLAYER 1 WINS');
    showMsg('🏆 ' + winner + ' — Click "Back to Menu" to play again');
  }

  updateHUD();
  drawScene();
  gameLoop = requestAnimationFrame(loop);
}

buildWeaponUI();
buildDifficultyUI();
